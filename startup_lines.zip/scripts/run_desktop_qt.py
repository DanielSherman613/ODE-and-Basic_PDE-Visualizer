from __future__ import annotations

import sys

from PyQt6.QtWidgets import QApplication

from scripts.run_desktop import buildExampleModel
from ode_pde_visualizer.ui.desktop.window import DesktopMainWindow


def main() -> None:
    app = QApplication(sys.argv)
    model = buildExampleModel()
    window = DesktopMainWindow(model)
    window.show()
    raise SystemExit(app.exec())


if __name__ == "__main__":
    main()
