# Architecture

Project architecture notes.
